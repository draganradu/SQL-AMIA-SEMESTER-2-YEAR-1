<?php 
// $dbname = 'ipascule'; //'anasirad_scoala'
// $dbuser = 'root'; //'anasirad_scoala'
// $dbpass = ''; //'radu este mult prea sexi pentru viata asta'
// $dbhost = 'localhost';

$dbname = 'anasirad_scoala';
$dbuser = 'anasirad_scoala'; 
$dbpass = 'radu este mult prea sexi pentru viata asta';
$dbhost = 'localhost';
?>